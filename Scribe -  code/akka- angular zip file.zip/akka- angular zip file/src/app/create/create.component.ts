import { Component, OnInit, Output,EventEmitter } from '@angular/core';
import * as firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/firestore';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
 editorConfig:any;
 title:string;
 content:string;
 @Output('postCreated') postCreated=new EventEmitter();
  constructor() { 
    this. editorConfig={
      "editable":true,
      "spellcheck":true,
      "height":"auto",
      "minHeigth":"150px",
      "width":"auto",
      "minWidth":"0",
      "translate":"yes",
      "enableToolbar":true,
      "showToolbar":false,
      "placeholder":"Enter text here..",
      "imageEndPoint":" ",
      "toolbar":[
        ["bold","italic","underline","strikeThrough",
        "superscript","subscript"],
        ["justifyLeft","jistufyRight","justifyCentre","indent","outdent",
        "justifyFull"],
        ["cut","copy","delete","undo","redo","remove Format"],
        ["paragraph","blockquote","removeBlckquote",
          "horizontalLine","orderedList","unorderedList"],
          ["link","unlink"],
          ["code"]

        ]
    }
  }

  ngOnInit() {
  }
  CreatePost()
  {
    firebase.firestore().settings({
      timestampsInSnapshots:true
    });
    firebase.firestore().collection("posts").add({
    title:this.title,
    content:this.content,
    owner:firebase.auth().currentUser.uid,
    created:firebase.firestore.FieldValue.serverTimestamp()
    }).then((data)=>
    {
      console.log(data);
      this.postCreated.emit();
    }).catch((error)=>
    {
      console.log(error);
    })
  }
}
